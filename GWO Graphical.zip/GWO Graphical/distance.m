function dis = distance(position,xprey,yprey)
X=position(1);
Y=position(2);
dis=sqrt((X-xprey)^2+(Y-yprey)^2);
end

